@echo off
title Xenon Ventilation Studio
echo.
echo ===================================
echo   Xenon Ventilation Studio
echo ===================================
echo.

REM Kill anything on port 5500
for /f "tokens=5" %%a in ('netstat -aon ^| findstr ":5500" ^| findstr "LISTENING"') do (
    taskkill /f /pid %%a >nul 2>&1
)

echo Starting Vite dev server...
echo.
echo DO NOT close this window while using the app.
echo Press Ctrl+C to stop the server.
echo.

npx vite

pause
